/**
 * Unit tests for the action's main functionality, src/main.ts
 *
 * These should be run as if the action was called from a workflow.
 * Specifically, the inputs listed in `action.yml` should be set as environment
 * variables following the pattern `INPUT_<INPUT_NAME>`.
 */

import * as core from '@actions/core'
import { Job } from '../src/main'
import * as helper from '../src/helper'
import { Wireguard, Runner } from '../src/helper'
import { btoa } from 'buffer'

// Mock the action's main function
let runMock: jest.SpyInstance
let cleanupMock: jest.SpyInstance

// Mock the GitHub Actions core library
let errorMock: jest.SpyInstance
let getInputMock: jest.SpyInstance
let setFailedMock: jest.SpyInstance
let saveStateMock: jest.SpyInstance
let warningMock: jest.SpyInstance

describe('action', () => {
  beforeEach(() => {
    jest.clearAllMocks()

    errorMock = jest.spyOn(core, 'error').mockImplementation()
    getInputMock = jest.spyOn(core, 'getInput').mockImplementation()
    setFailedMock = jest.spyOn(core, 'setFailed').mockImplementation()
    saveStateMock = jest.spyOn(core, 'saveState').mockImplementation()
    warningMock = jest.spyOn(core, 'warning').mockImplementation()
  })

  it('execute run', async () => {
    runMock = jest.spyOn(Job, 'run').mockImplementation()
    cleanupMock = jest.spyOn(Job, 'cleanup').mockImplementation()
    jest.spyOn(Job, 'isPost').mockReturnValue(false)
    await Job.execute()
    expect(runMock).toHaveBeenCalled()
    expect(cleanupMock).not.toHaveBeenCalled()
    expect(errorMock).not.toHaveBeenCalled()
  })

  it('execute cleanup', async () => {
    runMock = jest.spyOn(Job, 'run').mockImplementation()
    cleanupMock = jest.spyOn(Job, 'cleanup').mockImplementation()
    jest.spyOn(Job, 'isPost').mockReturnValue(true)
    await Job.execute()
    expect(runMock).not.toHaveBeenCalled()
    expect(cleanupMock).toHaveBeenCalled()
    expect(errorMock).not.toHaveBeenCalled()
  })

  it('run with no temporary directory', async () => {
    delete process.env['RUNNER_TEMP']
    await Job.run()
    expect(setFailedMock).toHaveBeenCalledWith(
      'No temporary directory set for runner.'
    )
  })

  it('run with invalid temporary directory', async () => {
    process.env['RUNNER_TEMP'] = 'invalid'
    await Job.run()
    expect(setFailedMock).toHaveBeenCalledWith(
      'Could not change directory to invalid'
    )
  })

  it('run with no allowed hosts', async () => {
    jest.spyOn(Runner, 'useTemporaryDirectory').mockImplementation()
    getInputMock.mockImplementation((name: string) => {
      if (name === 'wireguard_allowed_hosts') {
        return ' , '
      }
    })
    await Job.run()
    expect(setFailedMock).toHaveBeenCalledWith('No allowed hosts specified')
  })

  it('run with invalid config', async () => {
    const tempDirMock = jest
      .spyOn(Runner, 'useTemporaryDirectory')
      .mockImplementation()
    jest.spyOn(helper, 'resolveHosts').mockResolvedValue(['10.10.10.10'])
    getInputMock.mockImplementation((name: string) => {
      if (name === 'wireguard_base64_config') {
        return 'base64_config'
      } else if (name === 'wireguard_interface') {
        return 'wg0'
      } else if (name === 'wireguard_allowed_hosts') {
        return 'allowed_hosts'
      } else if (name === 'wireguard_mtu') {
        return '{"linux": 1420, "darwin": 1420, "windows": 1420}'
      }
    })
    const installWireguardMock = jest
      .spyOn(Wireguard, 'installWireguard')
      .mockImplementation()
    await Job.run()
    expect(tempDirMock).toHaveBeenCalled()
    expect(saveStateMock).toHaveBeenCalled()
    expect(installWireguardMock).not.toHaveBeenCalled()
    expect(setFailedMock).toHaveBeenCalledWith('Invalid base64 encoded config')
  })

  it('run and fail on installing wireguard', async () => {
    const tempDirMock = jest
      .spyOn(Runner, 'useTemporaryDirectory')
      .mockImplementation()
    jest.spyOn(helper, 'resolveHosts').mockResolvedValue(['10.10.10.10'])
    getInputMock.mockImplementation((name: string) => {
      if (name === 'wireguard_base64_config') {
        return btoa(`some config with <allowed_ips>`)
      } else if (name === 'wireguard_interface') {
        return 'wg0'
      } else if (name === 'wireguard_allowed_hosts') {
        return 'allowed_hosts'
      } else if (name === 'wireguard_mtu') {
        return '{"linux": 1420, "darwin": 1420, "windows": 1420}'
      }
    })
    const installWireguardMock = jest
      .spyOn(Wireguard, 'installWireguard')
      .mockRejectedValue(new Error('installWireguard failed'))
    await Job.run()
    expect(tempDirMock).toHaveBeenCalled()
    expect(installWireguardMock).toHaveBeenCalledWith(
      'wg0',
      'some config with 10.10.10.10/32'
    )
    expect(saveStateMock).toHaveBeenCalledWith('wireguardInterface', 'wg0')
    expect(installWireguardMock).toHaveBeenCalled()
    expect(setFailedMock).toHaveBeenCalledWith('installWireguard failed')
  })

  it('cleanup', async () => {
    const removeWireguardMock = jest
      .spyOn(Wireguard, 'removeWireguard')
      .mockImplementation()
    await Job.cleanup()
    expect(removeWireguardMock).toHaveBeenCalled()
    expect(errorMock).not.toHaveBeenCalled()
  })

  it('cleanup fails', async () => {
    const removeWireguardMock = jest
      .spyOn(Wireguard, 'removeWireguard')
      .mockRejectedValue(new Error('removeWireguard failed'))
    await Job.cleanup()
    expect(removeWireguardMock).toHaveBeenCalled()
    expect(warningMock).toHaveBeenCalled()
  })
})
