/**
 * Unit tests for the action's entrypoint, src/index.ts
 */

import { Job } from '../src/main'

describe('index', () => {
  it('calls execute when imported', async () => {
    const executeMock = jest.spyOn(Job, 'execute').mockImplementation()
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    require('../src/index')

    expect(executeMock).toHaveBeenCalled()
  })
})
