/**
 * Unit tests for src/helper.ts
 */

import * as core from '@actions/core'
import {
  resolveHost,
  resolveHosts,
  createWireguardConfig,
  Windows,
  Platform,
  Unix,
  Wireguard,
  ShellFactory,
  Runner,
  getMtu
} from '../src/helper'
import { expect } from '@jest/globals'
import { btoa } from 'buffer'

// Mock the GitHub Actions core library

describe('helper.ts', () => {
  beforeEach(() => {
    jest.clearAllMocks()

    jest.spyOn(core, 'debug').mockImplementation()
  })

  it('resolve an unknown host', async () => {
    jest.mock('dns', () => ({
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      resolve: (hostname: string, callback: any): void => {
        callback(new Error(`could not resolve '${hostname}'`), [])
      }
    }))
    await expect(resolveHost('foo.bar')).rejects.toThrow(
      `could not resolve 'foo.bar'`
    )
  })

  it('resolve artifact.monotype.com', async () => {
    jest.mock('dns', () => {
      return {
        promises: {
          Resolver() {
            return {
              resolveTxt: () => {
                return ['10.10.10.10', '10.10.10.11']
              }
            }
          }
        }
      }
    })
    await expect(resolveHost('artifact.monotype.com')).resolves.toHaveLength(2)
  })

  it('resolve artifact.monotype.com and confluence.monotype.com', async () => {
    jest.mock('dns', () => {
      return {
        promises: {
          Resolver() {
            return {
              resolveTxt: () => {
                return [
                  '10.10.10.10',
                  '10.10.10.11',
                  '10.10.10.12',
                  '10.10.10.13'
                ]
              }
            }
          }
        }
      }
    })
    await expect(
      resolveHosts(['artifact.monotype.com', 'confluence.monotype.com'])
    ).resolves.toHaveLength(4)
  })

  it('create wireguard config with invalid base64 config', () => {
    const base64_config = 'äöü'
    const addresses = ['10.10.10.10']
    const mtu = 1420
    expect(() => createWireguardConfig(base64_config, addresses, mtu)).toThrow(
      'Invalid base64 encoded config'
    )
  })

  it('create wireguard config with one ip', () => {
    const base64_config = btoa('AllowedIPs = <allowed_ips>')
    const addresses = ['10.10.10.10']
    const mtu = 1420
    expect(createWireguardConfig(base64_config, addresses, mtu)).toBe(
      'AllowedIPs = 10.10.10.10/32'
    )
  })

  it('create wireguard config with two ips', () => {
    const base64_config = btoa('AllowedIPs = <allowed_ips>')
    const addresses = ['10.10.10.10', '8.8.8.8']
    const mtu = 1420
    expect(createWireguardConfig(base64_config, addresses, mtu)).toBe(
      'AllowedIPs = 10.10.10.10/32,8.8.8.8/32'
    )
  })

  it('create wireguard config with mtu', () => {
    const base64_config = btoa('AllowedIPs = <allowed_ips>\nMTU = <mtu>')
    const addresses = ['10.10.10.10', '8.8.8.8']
    const mtu = 1420
    expect(createWireguardConfig(base64_config, addresses, mtu)).toBe(
      'AllowedIPs = 10.10.10.10/32,8.8.8.8/32\nMTU = 1420'
    )
  })

  it('get mtu for linux', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('linux')
    const mtu = '{"linux": 1500, "windows": 1400, "macos": 1300}'
    expect(await getMtu(mtu)).toBe(1500)
  })

  it('get mtu for linux without being set', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('linux')
    const mtu = '{"windows": 1400, "macos": 1300}'
    expect(await getMtu(mtu)).toBe(1420)
  })

  // Windows

  it('run powershell commands with error', async () => {
    const commands = ['Get-Item test']
    const shell = new Windows()
    jest
      .spyOn(shell, 'runCommands')
      .mockRejectedValue(
        new Error("Failed to find 'test' because it does not exist")
      )
    await expect(shell.runCommands(commands)).rejects.toThrow(
      "test' because it does not exist"
    )
  })

  it('run powershell commands', async () => {
    const commands = ['echo "foo"', 'echo "bar"']
    const shell = new Windows()
    jest
      .spyOn(shell, 'runCommands')
      .mockReturnValue(Promise.resolve('foo\nbar\n'))
    // eslint-disable-next-line jest/valid-expect
    const result = expect(shell.runCommands(commands)).resolves
    await result.toContain('foo')
    await result.toContain('bar')
  })

  // unix

  it('bash does run only on Unix', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('win32')
    await expect(new Unix().runCommands([])).rejects.toThrow(
      'This function only runs on Unix systems'
    )
  })

  it('bash commands with error', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('linux')
    const commands = ['ls -al test']
    await expect(new Unix().runCommands(commands)).rejects.toThrow(
      "ls: cannot access 'test'"
    )
  })

  it('run bash commands', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('darwin')
    const commands = ['echo "foo"', 'echo "bar"']
    // eslint-disable-next-line jest/valid-expect
    const result = expect(new Unix().runCommands(commands)).resolves
    await result.toContain('foo')
    await result.toContain('bar')
  })

  // Wireguard installation on Windows
  it('install wireguard on Windows', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('win32')
    const shell = new Windows()
    const rc = jest.spyOn(shell, 'runCommands').mockResolvedValue('foo')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wgf = jest.spyOn(Wireguard, 'createConfigFile').mockReturnValue()
    const wg_interface = 'wg0'
    const wg_config = 'some config string'
    await Wireguard.installWireguard(wg_interface, wg_config)
    expect(rc).toHaveBeenCalledWith([
      'choco install wireguard',
      "Start-Process 'C:\\Program Files\\WireGuard\\wireguard.exe' -ArgumentList '/installtunnelservice', \"$PWD\\wg0.conf\" -Wait -NoNewWindow -PassThru",
      "Start-Process sc.exe -ArgumentList 'config', 'WireGuardTunnel$wg0', 'start= delayed-auto' -Wait -NoNewWindow -PassThru | Out-Null",
      'Start-Service -Name WireGuardTunnel$wg0 -ErrorAction SilentlyContinue'
    ])
    expect(wgf).toHaveBeenCalledWith(wg_interface, wg_config)
    expect(sh).toHaveBeenCalledWith('win32')
  })

  it('install wireguard fails on Windows', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('win32')
    const shell = new Windows()
    const rc = jest.spyOn(shell, 'runCommands').mockRejectedValue('bar')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wgf = jest.spyOn(Wireguard, 'createConfigFile').mockReturnValue()
    const wg_interface = 'wg0'
    const wg_config = 'some config string'
    await expect(
      Wireguard.installWireguard(wg_interface, wg_config)
    ).rejects.toThrow('bar')
    expect(rc).toHaveBeenCalledWith([
      'choco install wireguard',
      "Start-Process 'C:\\Program Files\\WireGuard\\wireguard.exe' -ArgumentList '/installtunnelservice', \"$PWD\\wg0.conf\" -Wait -NoNewWindow -PassThru",
      "Start-Process sc.exe -ArgumentList 'config', 'WireGuardTunnel$wg0', 'start= delayed-auto' -Wait -NoNewWindow -PassThru | Out-Null",
      'Start-Service -Name WireGuardTunnel$wg0 -ErrorAction SilentlyContinue'
    ])
    expect(wgf).toHaveBeenCalledWith(wg_interface, wg_config)
    expect(sh).toHaveBeenCalledWith('win32')
  })

  // Wireguard installation on Linux

  it('install wireguard on Linux', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('linux')
    const shell = new Unix()
    const rc = jest.spyOn(shell, 'runCommands').mockResolvedValue('foo')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wgf = jest.spyOn(Wireguard, 'createConfigFile').mockReturnValue()
    const wg_interface = 'wg0'
    const wg_config = 'some config string'
    await Wireguard.installWireguard(wg_interface, wg_config)
    expect(rc).toHaveBeenCalledWith([
      'sudo apt-get update',
      'sudo apt-get install -y wireguard',
      'sudo wg-quick up $PWD/wg0.conf'
    ])
    expect(wgf).toHaveBeenCalledWith(wg_interface, wg_config)
    expect(sh).toHaveBeenCalledWith('linux')
  })

  it('install wireguard fails on Linux', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('linux')
    const shell = new Unix()
    const rc = jest.spyOn(shell, 'runCommands').mockRejectedValue('bar')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wgf = jest.spyOn(Wireguard, 'createConfigFile').mockReturnValue()
    const wg_interface = 'wg0'
    const wg_config = 'some config string'
    await expect(
      Wireguard.installWireguard(wg_interface, wg_config)
    ).rejects.toThrow('bar')
    expect(rc).toHaveBeenCalledWith([
      'sudo apt-get update',
      'sudo apt-get install -y wireguard',
      'sudo wg-quick up $PWD/wg0.conf'
    ])
    expect(wgf).toHaveBeenCalledWith(wg_interface, wg_config)
    expect(sh).toHaveBeenCalledWith('linux')
  })

  // Wireguard installation on Darwin

  it('install wireguard on Darwin', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('darwin')
    const shell = new Unix()
    const rc = jest.spyOn(shell, 'runCommands').mockResolvedValue('foo')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wgf = jest.spyOn(Wireguard, 'createConfigFile').mockReturnValue()
    const wg_interface = 'wg0'
    const wg_config = 'some config string'
    await Wireguard.installWireguard(wg_interface, wg_config)
    expect(rc).toHaveBeenCalledWith([
      'brew update',
      'brew install wireguard-tools',
      'sudo wg-quick up $PWD/wg0.conf'
    ])
    expect(wgf).toHaveBeenCalledWith(wg_interface, wg_config)
    expect(sh).toHaveBeenCalledWith('darwin')
  })

  it('install wireguard fails on Darwin', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('darwin')
    const shell = new Unix()
    const rc = jest.spyOn(shell, 'runCommands').mockRejectedValue('bar')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wgf = jest.spyOn(Wireguard, 'createConfigFile').mockReturnValue()
    const wg_interface = 'wg0'
    const wg_config = 'some config string'
    await expect(
      Wireguard.installWireguard(wg_interface, wg_config)
    ).rejects.toThrow('bar')
    expect(rc).toHaveBeenCalledWith([
      'brew update',
      'brew install wireguard-tools',
      'sudo wg-quick up $PWD/wg0.conf'
    ])
    expect(wgf).toHaveBeenCalledWith(wg_interface, wg_config)
    expect(sh).toHaveBeenCalledWith('darwin')
  })

  // Wireguard installation on unknown OS
  it('install wireguard on unknown OS', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('foo')
    const wg_interface = 'wg0'
    const wg_config = 'some config string'
    await expect(
      Wireguard.installWireguard(wg_interface, wg_config)
    ).rejects.toThrow('Wireguard is not supported on foo')
  })

  // Wireguard removal on Windows
  it('remove wireguard on Windows', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('win32')
    const shell = new Windows()
    const rc = jest.spyOn(shell, 'runCommands').mockResolvedValue('foo')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wg_interface = 'wg0'
    await Wireguard.removeWireguard(wg_interface)
    expect(rc).toHaveBeenCalledWith(['choco uninstall -y -f wireguard'])
    expect(sh).toHaveBeenCalledWith('win32')
  })

  it('fail to remove wireguard on Windows', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('win32')
    const shell = new Windows()
    const rc = jest.spyOn(shell, 'runCommands').mockRejectedValue('bar')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wg_interface = 'wg0'
    await expect(Wireguard.removeWireguard(wg_interface)).rejects.toThrow('bar')
    expect(rc).toHaveBeenCalledWith(['choco uninstall -y -f wireguard'])
    expect(sh).toHaveBeenCalledWith('win32')
  })

  // Wireguard removal on Linux
  it('remove wireguard on Linux', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('linux')
    const shell = new Unix()
    const rc = jest.spyOn(shell, 'runCommands').mockResolvedValue('foo')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wg_interface = 'wg0'
    await Wireguard.removeWireguard(wg_interface)
    expect(rc).toHaveBeenCalledWith(['sudo apt remove -y wireguard'])
    expect(sh).toHaveBeenCalledWith('linux')
  })

  it('fail to remove wireguard on Linux', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('linux')
    const shell = new Unix()
    const rc = jest.spyOn(shell, 'runCommands').mockRejectedValue('bar')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wg_interface = 'wg0'
    await expect(Wireguard.removeWireguard(wg_interface)).rejects.toThrow('bar')
    expect(rc).toHaveBeenCalledWith(['sudo apt remove -y wireguard'])
    expect(sh).toHaveBeenCalledWith('linux')
  })

  // Wireguard removal on Darwin
  it('remove wireguard on Darwin', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('darwin')
    const shell = new Unix()
    const rc = jest.spyOn(shell, 'runCommands').mockResolvedValue('foo')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wg_interface = 'wg0'
    await Wireguard.removeWireguard(wg_interface)
    expect(rc).toHaveBeenCalledWith(['brew uninstall wireguard-tools'])
    expect(sh).toHaveBeenCalledWith('darwin')
  })

  it('fail to remove wireguard on Darwin', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('darwin')
    const shell = new Unix()
    const rc = jest.spyOn(shell, 'runCommands').mockRejectedValue('bar')
    const sh = jest.spyOn(ShellFactory, 'createShell').mockReturnValue(shell)
    const wg_interface = 'wg0'
    await expect(Wireguard.removeWireguard(wg_interface)).rejects.toThrow('bar')
    expect(rc).toHaveBeenCalledWith(['brew uninstall wireguard-tools'])
    expect(sh).toHaveBeenCalledWith('darwin')
  })

  // Wireguard removal on unknown OS
  it('remove wireguard on unknown OS', async () => {
    jest.spyOn(Platform, 'getOs').mockReturnValue('foo')
    const wg_interface = 'wg0'
    await expect(Wireguard.removeWireguard(wg_interface)).rejects.toThrow(
      'Wireguard is not supported on foo'
    )
  })

  // Runner no temporary directory set
  it('use no temporary directory', async () => {
    delete process.env.RUNNER_TEMP
    await expect(Runner.useTemporaryDirectory()).rejects.toThrow(
      'No temporary directory set for runner.'
    )
  })

  // Runner use temporary directory
  it('use invalid temporary directory', async () => {
    process.env['RUNNER_TEMP'] = 'invalid'
    await expect(Runner.useTemporaryDirectory()).rejects.toThrow(
      'Could not change directory to invalid'
    )
    delete process.env.RUNNER_TEMP
  })

  // Runner use temporary directory
  it('use temporary directory', async () => {
    process.env['RUNNER_TEMP'] = '.'
    await expect(Runner.useTemporaryDirectory()).resolves.not.toThrow()
    delete process.env.RUNNER_TEMP
  })
})
