# TypeScript Action for WireGuard

This action installs WireGuard on the runner and sets up a WireGuard interface.
It takes a base64 encoded WireGuard configuration file as input.
The AllowedIps of the interface hast to contain a token <allowed_hosts>.
The token will be replaced with the dns-resolved ip addresses of the specified hosts.
This is necessary as the dns lookup for hosts located in AWS can change over time.
The established WireGuard tunnel will add routes for those ip addresses, so that
only their traffic is routed through
the tunnel.

## Inputs

### `wireguard_base64_config`

**Required** base64 encoded WireGuard configuration file.

---

#### Unencoded example

```ini
[Interface]  
PrivateKey = <private wireguard key of the client>
Address = 10.8.0.2/32

[Peer]  
PublicKey = <public wireguard key of the server>  
AllowedIPs = <allowed_ips>, 10.8.0.1/24  
Endpoint = <endpoint name or ip>:51820
```

&lt;allowed_ips&gt; will be replaced with the resolved ip addresses of wireguard_allowed_hosts.
Everything other tag has to be replace with real values.

### `wireguard_allowed_hosts`

**Optional** Comma separated list of hosts to resolve. The resolved ip
addresses will be used as &lt;allowed_ips&gt; in the Wireguard
configuration file.
This currently defaults to 'artifact.monotype.com' and 'sonar.monotype.com'.

### `wireguard_interface_name`

**Optional** Name of the WireGuard interface. Default `"wg0"`.

### `wirgeuard_mtu'

**Optional** MTU of the WireGuard interface. Default `"1420"`.  
This is a json string with the following format:  
```{  "linux": 1420, "macos": 1420, "windows": 1420 }```
