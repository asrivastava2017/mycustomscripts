/**
 * The entrypoint for the action.
 */
import { Job } from './main'

// eslint-disable-next-line @typescript-eslint/no-floating-promises
Job.execute()
