import * as core from '@actions/core'

/**
 * Indicates whether the POST action is running
 */
export const IsPost = !!core.getState('isPost')

/**
 * The repository path for the POST action. The value is empty during the MAIN action.
 */
export const WireguardInterface = core.getState('wireguardInterface')

/**
 * Save the wireguard interface for the POST action to use.
 */
export function setWireguardInterface(wireguardInterface: string): void {
  core.saveState('wireguardInterface', wireguardInterface)
}

// Publish a variable so that when the POST action runs, it can determine it should run the cleanup logic.
// This is necessary since we don't have a separate entry point.
if (!IsPost) {
  core.saveState('isPost', 'true')
}
