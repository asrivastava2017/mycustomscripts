import * as core from '@actions/core'
import * as stateHelper from './state-helper'
import {
  resolveHosts,
  createWireguardConfig,
  Wireguard,
  Runner,
  getMtu
} from './helper'

export class Job {
  static async run(): Promise<void> {
    try {
      await Runner.useTemporaryDirectory()
      core.setSecret('wireguard_base64_config')
      const allowed_hosts: string[] = core
        .getInput('wireguard_allowed_hosts')
        .split(',')
        .map(s => s.trim())
        .filter(s => s.length > 0)
      if (allowed_hosts.length === 0) {
        throw new Error('No allowed hosts specified')
      }
      const mtu: number = await getMtu(core.getInput('wireguard_mtu'))
      const allowed_ips = await resolveHosts(allowed_hosts)
      const wg_interface: string = core.getInput('wireguard_interface')
      stateHelper.setWireguardInterface(wg_interface)
      const wg_config: string = createWireguardConfig(
        core.getInput('wireguard_base64_config'),
        allowed_ips,
        mtu
      )
      await Wireguard.installWireguard(wg_interface, wg_config)
    } catch (error) {
      // Fail the workflow run if an error occurs
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      core.setFailed(`${(error as any)?.message ?? error}`)
    }
  }

  static async cleanup(): Promise<void> {
    try {
      await Wireguard.removeWireguard(stateHelper.WireguardInterface)
    } catch (error) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      core.warning(`${(error as any)?.message ?? error}`)
    }
  }

  static isPost(): boolean {
    return stateHelper.IsPost
  }

  static async execute(): Promise<void> {
    // Main
    if (!Job.isPost()) {
      return Job.run()
    }
    // Post
    else {
      return Job.cleanup()
    }
  }
}
