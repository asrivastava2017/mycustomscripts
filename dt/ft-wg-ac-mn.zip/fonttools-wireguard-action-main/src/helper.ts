import * as core from '@actions/core'
import * as dns from 'node:dns'
import { PowerShell, InvocationResult, InvocationError } from 'node-powershell'
import { platform } from 'os'

import exec from 'child_process'
import * as process from 'process'

import * as fs from 'fs'

export interface Mtus {
  linux: number
  windows: number
  macos: number
}

export async function getMtu(mtu: string): Promise<number> {
  const os = Platform.getOs()
  const mtus = JSON.parse(mtu) as Mtus
  if (os === 'linux') {
    return mtus.linux ? mtus.linux : 1420
  } else if (os === 'win32') {
    return mtus.windows ? mtus.windows : 1420
  } else if (os === 'darwin') {
    return mtus.macos ? mtus.macos : 1420
  } else {
    throw new Error(`Unsupported OS: ${os}`)
  }
}

export async function resolveHost(hostname: string): Promise<string[]> {
  return new Promise((resolve, reject) => {
    dns.resolve(hostname, (err, addresses) => {
      if (err) reject(new Error(`could not resolve '${hostname}'`))
      resolve(addresses)
    })
  })
}

export async function resolveHosts(hostnames: string[]): Promise<string[]> {
  const addresses: string[][] = await Promise.all(
    hostnames.map(async hostname => resolveHost(hostname))
  )
  return addresses.flat()
}

export function createWireguardConfig(
  base64_config: string,
  addresses: string[],
  mtu: number
): string {
  if (!base64_config || base64_config.trim().length === 0) {
    throw new Error(`Invalid base64 encoded config`)
  }
  let config = ''
  try {
    config = atob(base64_config)
  } catch (error) {
    throw new Error(`Invalid base64 encoded config`)
  }
  if (!config.includes('<allowed_ips>')) {
    throw new Error(`Invalid wireguard config`)
  }
  return config
    .replace(
      '<allowed_ips>',
      addresses.map(address => `${address}/32`).join(',')
    )
    .replace('<mtu>', mtu.toString())
}

export class Platform {
  static getOs(): string {
    return platform()
  }
}

export interface Shell {
  runCommands(commands: string[]): Promise<string>
}

export class Windows implements Shell {
  async runCommands(commands: string[]): Promise<string> {
    return new Promise((resolve, reject) => {
      const shell = new PowerShell({
        pwsh: true,
        executableOptions: {
          '-ExecutionPolicy': 'Bypass',
          '-NonInteractive': true,
          '-NoProfile': false
        }
      })
      core.debug(`Running commands:\n${commands.join('\n')}`)
      shell
        .invoke(commands.join('\n'))
        // eslint-disable-next-line github/no-then
        .then(async (result: InvocationResult) => {
          await shell.dispose()
          if (result.hadErrors) {
            reject(new Error(result.stderr ? result.stderr.toString() : ''))
          } else {
            core.debug(result.stdout ? result.stdout.toString() : '')
            resolve(result.stdout ? result.stdout.toString() : '')
          }
        })
        // eslint-disable-next-line github/no-then
        .catch(async (error: InvocationError) => {
          await shell.dispose()
          reject(new Error(error.message))
        })
    })
  }
}

export class Unix implements Shell {
  async runCommands(commands: string[]): Promise<string> {
    return new Promise((resolve, reject) => {
      if (Platform.getOs() !== 'linux' && Platform.getOs() !== 'darwin') {
        reject(new Error('This function only runs on Unix systems'))
      }
      core.debug(`Running commands:\n${commands.join('\n')}`)
      exec.exec(
        commands.join('\n'),
        { shell: 'bash', env: process.env },
        (error, stdout, stderr) => {
          if (error) {
            reject(new Error(stderr))
          } else {
            core.debug(stdout)
            resolve(stdout)
          }
        }
      )
    })
  }
}

export class ShellFactory {
  static createShell(os: string): Shell {
    if (os === 'win32') {
      return new Windows()
    } else if (os === 'linux' || os === 'darwin') {
      return new Unix()
    } else {
      throw new Error(`Unsupported OS: ${os}`)
    }
  }
}

export class Wireguard {
  private static installation: { [key: string]: string[] } = {
    darwin: [
      'brew update',
      'brew install wireguard-tools',
      'sudo wg-quick up $PWD/<interface>.conf'
    ],
    linux: [
      'sudo apt-get update',
      'sudo apt-get install -y wireguard',
      'sudo wg-quick up $PWD/<interface>.conf'
    ],
    win32: [
      'choco install wireguard',
      `Start-Process 'C:\\Program Files\\WireGuard\\wireguard.exe' -ArgumentList '/installtunnelservice', "$PWD\\<interface>.conf" -Wait -NoNewWindow -PassThru`,
      `Start-Process sc.exe -ArgumentList 'config', 'WireGuardTunnel$<interface>', 'start= delayed-auto' -Wait -NoNewWindow -PassThru | Out-Null`,
      `Start-Service -Name WireGuardTunnel$<interface> -ErrorAction SilentlyContinue`
    ]
  }

  private static remove: { [key: string]: string[] } = {
    darwin: ['brew uninstall wireguard-tools'],
    linux: ['sudo apt remove -y wireguard'],
    win32: ['choco uninstall -y -f wireguard']
  }

  static createConfigFile(wg_interface: string, wg_config: string): void {
    core.debug(`Creating wireguard config file ${wg_interface}.conf`)
    fs.writeFileSync(`${wg_interface}.conf`, wg_config)
  }

  static async installWireguard(
    wg_interface: string,
    wg_config: string
  ): Promise<boolean> {
    return new Promise((resolve, reject) => {
      const os = Platform.getOs()
      if (Wireguard.installation[os] === undefined) {
        reject(new Error(`Wireguard is not supported on ${os}`))
      } else {
        core.debug(`Installing wireguard on ${os}`)
        Wireguard.createConfigFile(wg_interface, wg_config)
        const commands = Wireguard.installation[os].map(command =>
          command.replace('<interface>', wg_interface)
        )
        const shell = ShellFactory.createShell(os)
        shell
          .runCommands(commands)
          // eslint-disable-next-line github/no-then
          .then(() => {
            resolve(true)
          })
          // eslint-disable-next-line github/no-then
          .catch(error => {
            reject(new Error(error))
          })
          // eslint-disable-next-line github/no-then
          .finally(() => {
            core.debug('clearing wireguard config file')
            if (fs.existsSync(`${wg_interface}.conf`)) {
              fs.writeFileSync(`${wg_interface}.conf`, '')
            }
          })
      }
    })
  }

  static async removeWireguard(wg_interface: string): Promise<boolean> {
    return new Promise((resolve, reject) => {
      const os = Platform.getOs()
      if (Wireguard.remove[os] === undefined) {
        reject(new Error(`Wireguard is not supported on ${os}`))
      } else {
        core.debug(`Removing wireguard on ${os}`)
        const commands = Wireguard.remove[os].map(command =>
          command.replace('<interface>', wg_interface)
        )
        const shell = ShellFactory.createShell(os)
        shell
          .runCommands(commands)
          // eslint-disable-next-line github/no-then
          .then(() => {
            resolve(true)
          })
          // eslint-disable-next-line github/no-then
          .catch((error: string) => {
            reject(new Error(error))
          })
      }
    })
  }
}

export class Runner {
  static async useTemporaryDirectory(): Promise<void> {
    return new Promise((resolve, reject) => {
      const tempDir = process.env['RUNNER_TEMP'] ?? ''
      if (!tempDir) {
        reject(new Error('No temporary directory set for runner.'))
      }
      try {
        core.debug(`Changing directory to ${tempDir}`)
        process.chdir(tempDir)
        resolve()
      } catch (err) {
        reject(new Error(`Could not change directory to ${tempDir}`))
      }
    })
  }
}
